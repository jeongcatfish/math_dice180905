var fs = require('fs');

setInterval(function(){
  fs.readFile('numberOf.txt', 'utf8', function (err,data) {
    if (err) {
      return console.log(err);
    }
    console.log(data);
  });

},1000)
