var state = 0;

function n12() //테스트 이벤트(주사위가 던져졌을 때) 6번 라인.
{
    var top=$("#box_12").css("top");
    if(state==0)
      top = top.substring(0,3);
    else if(state==1)
      top = top.substring(0,2);

    top*=1; //문자열 숫자로 변신
    top=top-20;

    if(top<=100)
      state=2;

    console.log("top : " + top);
    console.log("STSTSTSTSTTSTSTSTST " +state);

    ct=ct+1;  //누적 카운트 증가
    console.log("send ct : " +ct);  // 누적 카운트 확인

    $("#_count").text(ct);   //누적 카운트 html에 표현
    socket.emit("write",ct); //메모장에 저장하기 위해 노드로 전송. /노트에서 메모장에 저장

    $("#box_12").css("top",top+"px");  // 위로 위로
    if(height==0)
    {
      $("#box_12").css("top","600px");
      location.href="http://127.0.0.1:3000"
    }
}
