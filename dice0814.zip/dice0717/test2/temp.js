top_n2=$("#n2").css("top"); // 누적 박스의 높이 값
height_n2 = $("#n2").css("height"); //현재 누적 박스의 top,height_n2의 값을 가져온다.
console.log("current n2 height : "+height_n2);

top_n2 = eval(top_n2.replace("px","")); // ex) 600px -----> 600
height_n2 = eval(height_n2.replace("px",""));

console.log("current n2 height : "+height_n2);
if(state_of_rotation_rotation == 0)
{
  top_n2=top_n2-30; //10px 씩 위로 증가
  height_n2=height_n2+30; //10px씩 위로 증가
}
else if(state_of_rotation_rotation == 1)
{
  top_n2=top_n2-10;
  height_n2 = height_n2+10;
}
else if(state_of_rotation_rotation == 2)
{
  top_n2=top_n2-5;
  height_n2 = height_n2+5;
}
else if(state_of_rotation_rotation == 3)
{
  top_n2=top_n2-2;
  height_n2 = height_n2+2;
}
else if(state_of_rotation_rotation == 4)
{
  top_n2=top_n2-1;
  height_n2 = height_n2+1;
}

console.log("top : " + top_n2);
console.log("height_n2 8 8 8 8 8 8 8  : " + height_n2);
console.log("state_of_rotation ---------- " +state_of_rotation);

ct=ct+1;  //누적 카운트 증가
console.log("send ct : " +ct);  // 누적 카운트 확인

$("#_count").text(ct);   //누적 카운트 html에 표현
socket.emit("write",ct); //메모장에 저장하기 위해 노드로 전송. /노트에서 메모장에 저장

$("#n2").css("top",top_n2+"px");  // 위로 위로
$("#n2").css("height",height_n2+"px"); // 위로 위로]a
top_n2=top_n2-70;
$("#plus").css("top",top_n2+"px");
$("#plus").css("opacity","1");
$("#plus").addClass("animated jello").one('webwitAnimationEnd mozAnimationEnd MsAnimationEnd oanimationend animationend',
function(){
  $(this).removeClass("animated jello");
  $(this).css("opacity","0");
});

if(height_n2 >500)
  init_all();
