var express = require('express');
var app = require('express')();
var server = require('http').createServer(app);

var io = require('socket.io')(server);
var fs = require('fs');


app.get('/', function(req, res) {
  res.sendFile(__dirname + '/index.html');
});


app.use(express.static('public'));

app.get('/image/:name',function (req,res){
    var filename = req.params.name;
    console.log(__dirname+'/image/'+filename);
    fs.exists(__dirname+'/image/'+filename, function (exists) {
        if (exists) {
            fs.readFile(__dirname+'/image/'+filename, function (err,data){
                res.end(data);
            });
        } else {
            res.end('file is not exists');
        }
    });
});

const file = 'numberOf.txt';
fs.access(file, fs.constants.F_OK, (err) => {
  console.log(`${file} ${err ? 'does not exist' : 'exists'}`);
});


io.on('connection',function(socket){
  console.log("connected");


  fs.readFile('count.txt', 'utf8', function(err, data) { //처음에 누적된 누적카운트 불러오기 그리고 보내기
      io.emit("cumulative_count",data);
      console.log("cumulative ct : "+data);
  });

  socket.on("write",function(data){ //누적 데이터 쓰기
      fs.writeFile('count.txt', data, 'utf8', function(err) {
      console.log('비동기적 파일 쓰기 완료');
    });
  });
});

setInterval(function(){ // 파이썬에서 메모장에 쓴 데이터 가져오기 from .txt
  fs.readFile('numberOf.txt', 'utf8', function (err,data) { //테이블1 에서 주사위 던져졌는지 계속 확인 하는 중...
    if (err) {
      return console.log(err); //에러...
    }
    io.emit("from_python",data); //index.html로 데이터를 보내기.
    console.log("table1_data : "+data); //확인.
  });

  fs.readFile('table2_data.txt', 'utf8', function (err,data) { //테이블2 에서 주사위 던져졌는지 계속 확인 하는 중...
    if (err) {
      return console.log(err); //에러...
    }
    io.emit("from_python2",data); //index.html로 데이터를 보내기.
    console.log("table2_data : "+data); //확인.
  });
},100)


server.listen(3000, function() {
  console.log('Socket IO server listening on port 3000');
});
